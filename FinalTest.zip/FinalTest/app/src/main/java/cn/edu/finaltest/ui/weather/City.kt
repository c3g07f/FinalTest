package cn.edu.finaltest.ui.weather

class City : ArrayList<CityItem>()