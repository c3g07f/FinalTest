package com.example.cqs.weather

data class CityInfo(
    val city: String,
    val citykey: String,
    val parent: String,
    val updateTime: String
)